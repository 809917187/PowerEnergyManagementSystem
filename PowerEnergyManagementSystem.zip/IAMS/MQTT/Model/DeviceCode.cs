﻿namespace IAMS.MQTT.Model {
    public enum DeviceCode {
        PCS = 5,
        GatewayTableModel = 1,
        EnergyStorageStackControl = 3
    }
}
