﻿using Microsoft.AspNetCore.Mvc;

namespace IAMS.Controllers {
    public class ProfitReportController : Controller {
        public IActionResult Index() {
            return View();
        }
    }
}
