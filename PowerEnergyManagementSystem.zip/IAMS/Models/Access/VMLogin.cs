﻿namespace IAMS.Models.Access.Login {
    public class VMLogin {
        
        

    }
}
