﻿namespace IAMS.ViewModels.ElectricityReport {
    public class ElectricityReportStationSummaryViewModel : ElectricityReportCommonData {
        public string PowerStationName { get; set; } = "NA";

    }
}
