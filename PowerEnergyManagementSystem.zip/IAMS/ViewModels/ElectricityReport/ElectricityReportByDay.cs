﻿namespace IAMS.ViewModels.ElectricityReport {
    public class ElectricityReportByDay : ElectricityReportCommonData {
        public DateTime day { get; set; }
    }
}
