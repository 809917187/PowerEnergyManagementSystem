﻿using IAMS.Models.User;

namespace IAMS.ViewModels.Access {
    public class UserManagementViewModels {
        public List<UserInfo> userInfos { set; get; }
    }
}
