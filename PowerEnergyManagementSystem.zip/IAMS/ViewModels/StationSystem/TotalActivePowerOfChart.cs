﻿namespace IAMS.ViewModels.StationSystem {
	public class TotalActivePowerOfChart {
		public List<object[]> ChartDataOfEnergyStorage { get; set; } = new List<object[]>();
		public List<object[]> ChartDataOfElectricGrid { get; set; } = new List<object[]>();
	}
}
